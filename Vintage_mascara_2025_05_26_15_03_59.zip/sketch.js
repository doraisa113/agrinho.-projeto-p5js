function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let campoX = 150, campoY = 350;
let cidadeX = 450, cidadeY = 350;
let nuvemX = 300, nuvemY = 100; // Posição da nuvem
let raindrops = []; // Array para armazenar as gotas de chuva
let treeSize = [10, 10]; // Tamanhos iniciais muito pequenos para as árvores
let treeGrowArea = 50; // Área de crescimento das árvores (distância onde as gotas podem crescer as árvores)

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(220);

  // Desenhando o campo e a cidade
  drawCampo(campoX, campoY);
  drawCidade(cidadeX, cidadeY);

  // Desenhando a nuvem e fazendo ela "chorar"
  drawNuvem(nuvemX, nuvemY);
  makeItRain(nuvemX, nuvemY);

  // Conexão entre campo e cidade (linha)
  stroke(0);
  line(campoX, campoY, cidadeX, cidadeY);

  // Animando a nuvem
  nuvemX += 0.5; // Movendo a nuvem para a direita
  if (nuvemX > width) {
    nuvemX = -100; // Reseta a nuvem quando ela sai da tela
  }
  
  // Fazendo as árvores crescerem quando atingidas pela água
  for (let drop of raindrops) {
    // Verifica se a gota caiu perto das árvores
    if (drop.y >= campoY - 50 && drop.x > campoX - 50 && drop.x < campoX + 50) {
      // Se cair perto da árvore, aumente o tamanho
      if (abs(drop.x - (campoX - 40)) < treeGrowArea) {
        treeSize[0] += 0.05; // Crescendo árvore 1
      }
      if (abs(drop.x - (campoX + 40)) < treeGrowArea) {
        treeSize[1] += 0.05; // Crescendo árvore 2
      }
    }
  }
}

// Função para desenhar o campo
function drawCampo(x, y) {
  fill(34, 139, 34); // Cor do campo (verde)
  rect(x - 50, y - 50, 100, 100); // Representando a fazenda

  // Desenhando árvores que crescem
  fill(139, 69, 19); // Cor das árvores
  ellipse(x - 40, y - 70, treeSize[0], treeSize[0]); // Árvore 1
  ellipse(x + 40, y - 70, treeSize[1], treeSize[1]); // Árvore 2
}

// Função para desenhar a cidade
function drawCidade(x, y) {
  fill(200, 200, 255); // Cor dos prédios
  rect(x - 40, y - 70, 30, 70); // Prédio 1
  rect(x + 10, y - 90, 30, 90); // Prédio 2

  fill(255, 0, 0); // Cor dos carros
  rect(x - 25, y + 20, 20, 10); // Carro 1
  rect(x + 10, y + 20, 20, 10); // Carro 2
}

// Função para desenhar a nuvem
function drawNuvem(x, y) {
  fill(255, 255, 255, 200); // Nuvem branca e semitransparente
  ellipse(x, y, 100, 60); // Forma da nuvem
  ellipse(x - 30, y + 10, 70, 50); // Parte de baixo da nuvem
  ellipse(x + 30, y + 10, 70, 50); // Parte de baixo da nuvem
}

// Função para gerar gotas de chuva
function makeItRain(x, y) {
  // Criando novas gotas de chuva
  if (frameCount % 2 == 0) {
    raindrops.push(createVector(x, y)); // Adiciona novas gotas à cada 2 frames
  }

  // Atualizando as gotas de chuva
  for (let i = raindrops.length - 1; i >= 0; i--) {
    let drop = raindrops[i];
    drop.y += 3; // Gotas caindo (movendo para baixo)

    // Remover gotas que saem da tela
    if (drop.y > height) {
      raindrops.splice(i, 1);
    }

    // Desenho das gotas
    fill(0, 0, 255);
    noStroke();
    ellipse(drop.x, drop.y, 5, 10); // Desenha a gota de chuva
  }
}
